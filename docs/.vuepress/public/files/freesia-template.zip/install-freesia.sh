#!/usr/bin/env bash

set -e  # 遇到错误立即退出

# 变量定义
MINECRAFT_VERSION="1.21.1"
PAPER_BUILD="132"
VELOCITY_VERSION="3.4.0-SNAPSHOT"
VELOCITY_BUILD="481"

FABRIC_LOADER_VERSION="0.16.10"
FABRIC_INSTALLER_VERSION="1.0.1"

FREESIA_VERSION="2.4.1"
FABRIC_API_VERSION="0.115.1+1.21.1"
YSM_VERSION="2.4.1"

# 确保目录存在
mkdir -p backend/plugins velocity/plugins worker/mods

# 下载 Paper 端
echo "正在下载 Paper 端 (Minecraft $MINECRAFT_VERSION, Build $PAPER_BUILD)..."
curl -o backend/paper.jar \
  "https://api.papermc.io/v2/projects/paper/versions/$MINECRAFT_VERSION/builds/$PAPER_BUILD/downloads/paper-$MINECRAFT_VERSION-$PAPER_BUILD.jar"

# 下载 Velocity 端
echo "正在下载 Velocity 端 ($VELOCITY_VERSION-$VELOCITY_BUILD)..."
curl -o velocity/velocity.jar \
  "https://api.papermc.io/v2/projects/velocity/versions/$VELOCITY_VERSION/builds/$VELOCITY_BUILD/downloads/velocity-$VELOCITY_VERSION-$VELOCITY_BUILD.jar"

# 下载 Fabric 端
echo "正在下载 Fabric 端 (Minecraft $MINECRAFT_VERSION, Loader $FABRIC_LOADER_VERSION, Installer $FABRIC_INSTALLER_VERSION)..."
curl -o worker/fabric.jar \
  "https://meta.fabricmc.net/v2/versions/loader/$MINECRAFT_VERSION/$FABRIC_LOADER_VERSION/$FABRIC_INSTALLER_VERSION/server/jar"

# 下载 Freesia Backend 插件（GitHub 需要 -L）
echo "正在下载 Freesia Backend 插件 ($FREESIA_VERSION)..."
curl -L -OJ "https://github.com/YesSteveModel/Freesia/releases/download/v$FREESIA_VERSION/Freesia-Backend-$FREESIA_VERSION-universal-all.jar"
mv "Freesia-Backend-$FREESIA_VERSION-universal-all.jar" backend/plugins/

# 下载 Freesia Velocity 插件
echo "正在下载 Freesia Velocity 插件 ($FREESIA_VERSION)..."
curl -L -OJ "https://github.com/YesSteveModel/Freesia/releases/download/v$FREESIA_VERSION/Freesia-Velocity-$FREESIA_VERSION-universal-all.jar"
mv "Freesia-Velocity-$FREESIA_VERSION-universal-all.jar" velocity/plugins/

# 下载 PacketEvents Velocity 插件
echo "正在下载 PacketEvents Velocity 插件 (2.7.0)..."
curl -o "velocity/plugins/packetevents-velocity-2.7.0.jar" \
  "https://cdn.modrinth.com/data/HYKaKraK/versions/d35A6L4P/packetevents-velocity-2.7.0.jar"

# 下载 Freesia Worker 插件
echo "正在下载 Freesia Worker 插件 ($FREESIA_VERSION)..."
curl -L -OJ "https://github.com/YesSteveModel/Freesia/releases/download/v$FREESIA_VERSION/Freesia-Worker-$FREESIA_VERSION-universal.jar"
mv "Freesia-Worker-$FREESIA_VERSION-universal.jar" worker/mods/

# 下载 Fabric API（Modrinth，手动指定文件名，防止 `+` 号问题）
echo "正在下载 Fabric API ($FABRIC_API_VERSION)..."
curl -o "worker/mods/fabric-api-$FABRIC_API_VERSION.jar" \
  "https://cdn.modrinth.com/data/P7dR8mSH/versions/aHOmYIWr/fabric-api-$FABRIC_API_VERSION.jar"

# 下载 YesSteveModel Fabric 插件（Modrinth，手动指定文件名）
echo "正在下载 YesSteveModel Fabric 插件 ($YSM_VERSION)..."
curl -o "worker/mods/yesstevemodel-fabric-$MINECRAFT_VERSION-$YSM_VERSION-release.jar" \
  "https://cdn.modrinth.com/data/86xjpqqS/versions/1cHRrrpZ/yesstevemodel-fabric-$MINECRAFT_VERSION-$YSM_VERSION-release.jar"

echo "所有文件下载完成，请通过各文件夹中的 start.sh 启动对应服务端。"
